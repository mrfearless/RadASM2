#include <windows.h>
#include <commctrl.h>

int DlgProc(HWND,UINT,WPARAM,LPARAM);

#define IDD_MAINDLG 1000

HINSTANCE hInstance;